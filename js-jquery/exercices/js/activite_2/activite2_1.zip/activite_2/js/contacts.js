
var Contact = {

			init: function(prenom,nom){
				this.prenom = prenom;
				this.nom = nom; 
			}, 
			decrire: function(){
				console.log("Nom: " + this.nom + " Prenom: " + this.prenom);
			}

}

var contacts =[];

contact1 = Object.create(Contact);
contact1.init("Carole", "Lévisse");
contact2 = Object.create(Contact)
contact2.init("Mélodie", "Nelsonne");

contacts.push(contact1);
contacts.push(contact2);

function options(){
	console.log("1: Liste des contacts")
	console.log("2: ajouter un contact")
	console.log("0: Quitter")

}


console.log("Bienvenue dans le gestionnaire de contacts");
//options();


//var choix = prompt("choissisez une option")

	
	while(choix !== "0" ){

		options();
		var choix = prompt("choissisez une option");


			 switch (choix){

				case "1": 
				console.log("Voici la liste des contacts: ")
				contacts.forEach(function(contact){
				contact.decrire();
				});
				break;
			

				case "2":
				var prenom = prompt("saisir un prenom");
				var nom = prompt("saisir un nom");
				var newContact = Object.create(Contact);
				newContact.init(prenom,nom);
				contacts.push(newContact);
				console.log("votre contact a été ajouté");
				break;

			
			}

	}

	if(choix == "0"){
		console.log("Au revoir!");
	}



