/* 
Activité : gestion des contacts
*/

// TODO : complétez le programme

// création choix
var contacts = [];

console.log("bienvenue dans le gestionnaire de contact");
console.log("1 : lister les contacts")
console.log("2 : ajouter un contact")
console.log("0 : quitter")
var choix = Number(prompt("choisissez une option"));
var essai = 0;


//création contact

var contact =
        {
            // Initialise le contact de base
            initContact: function (nom, prenom) {
                this.nom = nom;
                this.prenom = prenom;
            },
            // Renvoie la description du contact
            afficherContact: function () {
                var description = "Nom : " + this.nom + " , Prénom : " + this.prenom;
                return description;
 
            },
            ajouterContact: function (nom, prenom) {
                this.initContact(nom, prenom);
                contacts.push(this);
            },
        };

var contact1 = Object.create(contact);
	contact1.initContact("Levisse", "carole");

var contact2 = Object.create(contact);
	contact2.initContact("Nelsonne", "Melodie");	




contacts.push(contact1);
contacts.push(contact2);	

console.log(contacts[1]);

// création de la boucle
do
{
    var choix = Number(prompt("Choisissez une option"));
    switch (choix) // va executer les instructions correspondantes aux choix de l'utilisateur
    {
        case 0 :
            console.log("Au Revoir");
            break;
        case 1 :
            for (var i = 0; i < contacts.length; i++) //parcourir le tableau et les afficher.
            {
                console.log(contacts[i].afficherContact());
            }
 
            break;
 
        case 2 :
            var nouveauNom = prompt("Saisissez le nom du nouveau contact");
            var nouveauPrenom = prompt("Saisissez le prénom du nouveau contact");
 
            var nouveaucontact = Object.create(contact); 
            nouveaucontact.ajouterContact(nouveauNom, nouveauPrenom); // ajout du contact
            console.log("Le contact a bien était ajouté !");
            break;
 
    }
} while (choix !== 0);
