// Activité 2 - Gestionnaire de contacts

var Contact = {
    // Initialisation du contact
    init: function (nom, prenom) {
        this.nom = nom;
        this.prenom = prenom;
    }
};


// Création des contacts
var carole = Object.create(Contact);
carole.init("Lévisse", "Carole");

var melodie = Object.create(Contact);
melodie.init("Nelsonne", "Mélodie");

// Pour créer un nouveau contact
var ajoutContact = Object.create(Contact); 

// Tableau avec les différents choix possibles
var tab = ["Quitter", "Lister les contacts", "Ajouter un contact"];

var contacts = [carole, melodie];

// Message de bienvenue
console.log("Bienvenue dans le gestionnaire des contacts !");



// Boucle
while (option !== 0) {
    console.log("1 : " + tab[1]);
    console.log("2 : " + tab[2]);
    console.log("0 : " + tab[0]);
    
    var option = Number(prompt("Choisissez une option"));
    
    if (option === 0) { // Permet de quitter le gestionnaire de contacts
        console.log("Au revoir !");
        
    }
    else if (option === 1) { // Permet d'afficher la liste des contacts
        console.log("Voici la liste de tous vos contacts :");
        contacts.forEach(function (Contact) {
            console.log("Nom : " + Contact.nom + ", " + " Prénom : " + Contact.prenom)
        });
    }
    else if (option === 2) { // Permet d'ajouter un nouveau contact
        var nom = prompt("Entrez le nom du nouveau contact :");
        var prenom = prompt("Entrez le prénom du nouveau contact :");
        
        ajoutContact.init(nom, prenom);
        contacts.push(ajoutContact);
        console.log("Le nouveau contact a été ajouté !");
    }
    else {
        console.log("Saisie invalide");
    }
}


