"use strict";

var elmt_cube = $('#cube');
var elmt_btn = $('#btn');

$(document).ready(function () {

    elmt_btn.on('click', do_on_click);

    function do_on_click() {


         if (elmt_cube.css('left') === '0px' && elmt_cube.css('bottom') === '0px' ) {

            elmt_cube.css({
                
                left:'550px',
                right: '0px'
            });

        } 


        else if (elmt_cube.css('left') === '550px' && elmt_cube.css('right') === '0px' ) {

            elmt_cube.css({
                
                left:'550px',
                right: '0px',
                bottom:'550px'
            });

        } 


        else if (elmt_cube.css('left') === '550px' && elmt_cube.css('right') === '0px' && elmt_cube.css('bottom') === '550px' ) {

            elmt_cube.css({
                
                left:'',
                right: '550px',
            });

        } 



    }

    



});