"use strict";

$(document).ready(function () {

    $('img').on('click', function () {
   
        var src = $(this).attr('src');
        var alt = $(this).attr('alt');

        var src_normal = src.replace('small' , 'normal') ;
        console.log(src_normal);

        $('#galery').attr('src', src_normal);
        $('#galery').attr('alt', alt);

        $('#bottom').text(alt);

        $('#image-container').css('display', 'block');

        
    }); 

});