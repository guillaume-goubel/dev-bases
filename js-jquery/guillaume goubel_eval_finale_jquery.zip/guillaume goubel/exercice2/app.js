"use strict";

var elmt_input = $('#input');
var elmt_copy = $('#copy');


$(document).ready(function () {

    $(elmt_input).on('keyup', function () {

        elmt_copy.val(elmt_input.val());

    });


    


});