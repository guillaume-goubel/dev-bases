"use strict";

var input = $('#input');

var result1 = $('#result1');
var result2 = $('#result2');
var result3 = $('#result3');

$(document).ready(function () {
    




    $(input).on('keyup', function () {

        result1.html(input.val());

        /* var carre = input.val(); */
        
        var carre_num = parseInt(input.val()) * parseInt(input.val()) ;
        console.log(carre_num);
        result2.html(carre_num);

        var cube_num = parseInt(input.val()) * parseInt(input.val()) * parseInt(input.val())  ;
        console.log(cube_num);
        result3.html(cube_num);

    });




});