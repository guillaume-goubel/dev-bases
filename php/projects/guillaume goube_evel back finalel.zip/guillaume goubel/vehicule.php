<?php require_once __DIR__.'/public/partials/header.php'; ?>

<main>

    <div class="container">

        <div class="row">

            <div class="table-responsive">

                <table class="table table-hover table-bordered">

                    <thead align="center">
                        <th>Id vehicule</th>
                        <th>Marque</th>
                        <th>Modèle</th>
                        <th>Couleur</th>
                        <th>Immatriculation</th>
                        <th colspan=2> Edition </th>
                    </thead>

                    <tbody align="center">

                        <?php 

$sql = "SELECT * FROM vehicule";
$query = $db->query($sql);
$results = $query->fetchAll();

foreach ($results  as $key => $result) {
    
    echo '<tr>';

            echo'<td>' . $result['id_vehicule'] . '</td>';                               
            echo'<td>' . $result['marque'] . '</td>';                              
            echo'<td>' . $result['modele'] . '</td>';    
            echo'<td>' . $result['couleur'] . '</td>';
            echo'<td>' . $result['immatriculation']. '</td>';                           
                              
            echo '<td>';
            echo '<button class="btn-btn-success" id="modification"> Modification </button>';
            echo '</td>';
                                        
            echo'<td>';                        
            echo '<a class="btn btn-danger" href="deleteVehicule.php?id=' . $result['id_vehicule'] . ' "> Delete </a>'; 

                            
    echo '</tr>';

/* Database::disconnect();  *///on se deconnecte de la base;
}     

?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

    <!-- Vérification des formulaires -->

    <?php

$marque = $modele = $couleur = $immatriculation = null;

$formIsValid = false;

$DeleteConfirmation = false;

$array_errors = [];


if(!empty($_POST)){
    $marque = $_POST['marque'];
    $modele = $_POST['modele'];
    $couleur = $_POST['couleur'];
    $immatriculation = $_POST['immatriculation'];

    if (empty($marque)){
        $formIsValid= false;
        $array_errors['marque'] = "Il manque la marque";
    }

    if (empty($modele)){
        $formIsValid= false;
        $array_errors['modele'] = "Il manque le modele";
    }

    if (empty($couleur)){
        $formIsValid= false;
        $array_errors['couleur'] = "Il manque la couleur";
    }

    if (empty($immatriculation)){
        $formIsValid= false;
        $array_errors['immatriculation'] = "Il manque l'immatriculation";
    }


    if(!empty($_POST) && empty($array_errors))
    {
    $formIsValid = true;
    }
}

if($formIsValid === true){

    $sql = "INSERT INTO vehicule
    (marque, modele , couleur, immatriculation ) 
    VALUES
    (:marque, :modele , :couleur, :immatriculation )";

    $update = $db->prepare($sql);

    $marque = htmlspecialchars($marque);
    $update->bindValue(':marque', $marque, PDO::PARAM_STR);

    $modele = htmlspecialchars($modele);
    $update->bindValue(':modele', $modele, PDO::PARAM_STR);

    $couleur = htmlspecialchars($couleur);
    $update->bindValue(':couleur', $couleur, PDO::PARAM_STR);

    $immatriculation = htmlspecialchars($immatriculation);
    $update->bindValue(':immatriculation', $immatriculation, PDO::PARAM_STR);

    $update->execute(); 

}

?>


    <div class="row" id="form-insert">

        <form method='POST' action="#">
            <div class="form-group">
                <label for="exampleInputEmail1">Marque</label>
                <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Marque" name="marque">
                <div class="feedback">
                    <?php echo (isset($array_errors['marque']))?$array_errors['marque'] : ""  ;?>

                </div>

            </div>

            <div class="form-group">
                <label for="exampleInputEmail1">Modèle</label>
                <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Modèle" name="modele">
                <div class="feedback">
                    <?php echo (isset($array_errors['modele']))?$array_errors['modele'] : ""  ;?>

                </div>

            </div>

            <div class="form-group">
                <label for="exampleInputEmail1">Couleur</label>
                <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Couleur" name="couleur">
                <div class="feedback">
                    <?php echo (isset($array_errors['couleur']))?$array_errors['couleur'] : ""  ;?>

                </div>

            </div>

            <div class="form-group">
                <label for="exampleInputEmail1">Immatriculation</label>
                <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Immatriculation" name="immatriculation">
                <div class="feedback">
                    <?php echo (isset($array_errors['immatriculation']))?$array_errors['immatriculation'] : ""  ;?>

                </div>

            </div>

            <button type="submit" class="btn btn-ligth">Ajouter ce véhicule</button>
        </form>

    </div>

    <!-- Formulaire delete  -->






</main>

<?php require_once __DIR__.'/public/partials/footer.php'; ?>