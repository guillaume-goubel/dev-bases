<?php

// Donne la page actuelle
$siteName = 'WebFlix';

$currentPage = basename($_SERVER['SCRIPT_FILENAME'] ,".php");


