<?php require_once __DIR__.'/public/partials/header.php'; ?>

<main>

    <div class="container">

        <div class="row">

            <div class="table-responsive">

                <table class="table table-hover table-bordered">

                    <thead align="center">
                        <th>Id conducteur</th>
                        <th>Prenom</th>
                        <th>Nom</th>
                        <th colspan=2> Edition </th>
                    </thead>

                    <tbody align="center">

    <?php
    
    $sql = "SELECT * FROM conducteur";
    $query = $db->query($sql);
    $results = $query->fetchAll();

    foreach ($results  as $key => $result) {
    
    echo '<tr>';

            echo'<td>' . $result['id_conducteur']  . '</td>';                               
            echo'<td>' . $result['prenom']  . '</td>';                              
            echo'<td>' . $result['nom']  . '</td>';                            
                              
            echo '<td>';
            echo '<button class="btn-btn-success" id="modification"> Modification </button>';
            echo '</td>';
                                        
            echo'<td>';
            echo '<a class="btn btn-danger" href="delete.php?id=' . $result['id_conducteur'] . ' "> Delete </a>';                 
            echo '</td>';
                            
    echo '</tr>';

/* Database::disconnect();  *///on se deconnecte de la base;
}             
?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

    <!-- Vérification des formulaires -->
    <?php

    $prenom = $nom = null;

    $formIsValid= false;
    $DeleteConfirmation = false;

    $array_errors = [];

    if(!empty($_POST)){
        $prenom = $_POST['prenom'];
        $nom = $_POST['nom'];
    
        if (empty($prenom)){
            $formIsValid= false;
            $array_errors['prenom'] = "Il manque le prenom";
        }

        if (empty($nom)){
            $formIsValid= false;
            $array_errors['nom'] = "Il manque le nom";
        }

        
        if(!empty($_POST) && empty($array_errors))
        {
        $formIsValid = true;
        }
    }

    if($formIsValid === true){

        $sql = "INSERT INTO conducteur
        (prenom, nom) 
        VALUES
        (:prenom, :nom)";

        $update = $db->prepare($sql);

        $prenom = htmlspecialchars($prenom);
        $update->bindValue(':prenom', $prenom, PDO::PARAM_STR);

        $nom = htmlspecialchars($nom);
        $update->bindValue(':nom', $nom, PDO::PARAM_STR);

        $update->execute(); 

    }

    ?>


    <div class="row" id="form-insert">

        <form method='POST' action="#">
            <div class="form-group">
                <label for="exampleInputEmail1">Prenom</label>
                <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Prénom" name="prenom">         
                <div class="feedback">
                    <?php echo (isset($array_errors['prenom']))?$array_errors['prenom'] : ""  ;?>
                </div>
            </div>

            <div class="form-group">
                <label for="exampleInputEmail1">Nom</label>
                <input type="text" class="form-control" id="exampleInputEmail1"  placeholder="Nom" name="nom">         
                <div class="feedback">
                    <?php echo (isset($array_errors['nom']))?$array_errors['nom'] : ""  ;?>
                </div>
            </div>

            <button type="submit" class="btn btn-ligth">Ajouter ce conducteur</button>

        </form>

    </div>





</main>

<?php require_once __DIR__.'/public/partials/footer.php'; ?>