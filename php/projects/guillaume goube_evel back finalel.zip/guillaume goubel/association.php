<?php require_once __DIR__.'/public/partials/header.php'; ?>

<main>

    <div class="container">

        <div class="row">

            <div class="table-responsive">

                <table class="table table-hover table-bordered">

                    <thead align="center">
                        <th>Id association</th>
                        <th>Conducteur</th>
                        <th>Véhicule</th>
                        <th colspan=2> Edition </th>
                    </thead>

                    <tbody align="center">

            <?php 

            $sql = "SELECT * FROM conducteur
            INNER JOIN association_vehicule_conducteur ON association_vehicule_conducteur.conducteur_id = conducteur.id_conducteur 
            INNER JOIN vehicule ON association_vehicule_conducteur.vehicule_id = vehicule.id_vehicule";
            $query = $db->query($sql);
            $results = $query->fetchAll();

            foreach ($results  as $key => $result) {
    
    echo '<tr>';
            echo'<td>' . $result['id_association']. '</td>';                               
            echo'<td>' . $result['nom'].'<br>'.$result['id_conducteur'].'</td>';     
            echo'<td>' . $result['marque']." ".$result['modele'].'<br>'.$result['vehicule_id'].'</td>';                          
                                           
            echo '<td>';
            echo '<button class="btn-btn-success" id="modification"> Modification </button>';
            echo '</td>';
                                        
            echo'<td>';
            echo '<button class="btn-btn-danger">Suppression </button>';                            
            echo '</td>';                      
    echo '</tr>';

/* Database::disconnect();  *///on se deconnecte de la base;
}                        
?>
                    </tbody>

                </table>

            </div>

        </div>

    </div>

    <!-- Vérification des formulaires AJOUT -->

    <div class="row" id="form-insert">

        <form method='POST' action="#">

            <div class="form-group">

                    <label for="exampleFormControlSelect2">Choix du conducteur</label>
                    <select class="form-control" name="conducteur_choice">
                    <option selected></option>          
                    
                    <?php
                    $sql2 = "SELECT * FROM conducteur";
                    $query2 = $db->query($sql2);
                    $results_conducteur = $query2->fetchAll();

                    foreach ($results_conducteur as $key => $result_conducteur) {
                    echo '<option>'.$result_conducteur['prenom']." " .$result_conducteur['nom'] .'</option>';}?> 
                    </select>

                    <label for="exampleFormControlSelect2">Choix du véhicule</label>
                    <select class="form-control" name="conducteur_choice">
                    <option selected></option>

                    <?php
                    $sql2 = "SELECT * FROM vehicule";
                    $query2 = $db->query($sql2);
                    $results_vehicule = $query2->fetchAll();

                    foreach ($results_vehicule as $key => $result_vehicule) {
                    echo '<option>'.$result_vehicule['marque']." " .$result_vehicule['modele'] .'</option>';}?> 
                    </select>
        
            </div>

            <button type="submit" class="btn btn-ligth">Ajouter cette association</button>
        </form>

    </div>

</main>

<?php require_once __DIR__.'/public/partials/footer.php'; ?>