
var Elmt_btn_modification = $('.btn-btn-success');
var Elmt_form = $('#form-insert');

$(document).ready(function () {
    
/*     $(Elmt_btn_modification).on('click', function () {
        
        Elmt_form.css('display', 'block');  
        Elmt_form.toggle('display'); 
        console.log('hello');

    });
 */


});
