<?php require_once __DIR__.'/../../private/config/database.php'; 
require_once __DIR__.'/../../private/config/database.php'; 
require_once __DIR__.'/../../private/config/functions.php';

?>

<!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>

    </title>

    <!-- CDN -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <!-- BOOTSTRAP -->
    <link href="public/assets/styles/css/bootstrap.min.css" rel="stylesheet">
    <!-- <link href="public/assets/styles/css/mdb.min.css" rel="stylesheet"> -->

    <!-- MY-->
    <link href="public/assets/styles/css/styles.min.css" rel="stylesheet">

    <header>

        <nav class="site-header sticky-top py-1" id="main-nav">
            <div class="container d-flex flex-column flex-md-row justify-content-between">
                <a class="py-2 d-none d-md-inline-block" href="index.php">Conducteur</a>
                <a class="py-2 d-none d-md-inline-block" href="vehicule.php">Vehicule</a>
                <a class="py-2 d-none d-md-inline-block" href="association.php">Association</a>
            </div>
        </nav>
        
    </header>