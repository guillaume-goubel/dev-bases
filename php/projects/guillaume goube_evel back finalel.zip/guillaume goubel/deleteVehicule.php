<!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>

    </title>

    <!-- CDN -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO"
        crossorigin="anonymous">

    <!-- BOOTSTRAP -->
    <link href="public/assets/styles/css/bootstrap.min.css" rel="stylesheet">
    <!-- <link href="public/assets/styles/css/mdb.min.css" rel="stylesheet"> -->

    <!-- MY-->
    <link href="public/assets/styles/css/styles.min.css" rel="stylesheet">

    <?php

try{
    
    $db = new PDO ('mysql:host=localhost;dbname=vtc;charset=UTF8', 'root' , '');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE , PDO::FETCH_ASSOC); 

} 
 
 catch (Exception $e)
{
    echo $e ->getMessage();
    //redirection vers GOOGLE
    header('https://www.google.com/search?q='.$e->getMessage());
} 

 catch(PDOException $e) {
    echo "Database connection failed: " . $e->getMessage();
    echo '<img src="data/pictures/giphy.gif">';
    die('Aie Aie Aie');
}


$id_vehicule = null;
$deleteValidation = false;

if(!empty($_GET)){

    $id_vehicule = $_GET['id'];

    $sql = "DELETE FROM vehicule WHERE id_vehicule = :id ";   
    $delete = $db->prepare($sql);
    $delete->bindValue(':id', $id_vehicule, PDO::PARAM_INT);
}

if (!empty($_POST)){
    $deleteValidation = true;
}

var_dump($deleteValidation);

if ($deleteValidation){
    $delete->execute(); 
}

?>

    Etes-vous sur de supprimer le véhicule <?= $id_vehicule ;?> ?
    <form class="form-horizontal" action="#" method="POST">
        <button type="submit" class="btn btn-danger" name="confirme">Yes</button>
        <a class="btn" href="conducteur.php">No</a>
    </form>
    
    <?php require_once __DIR__.'/public/partials/footer.php'; ?>